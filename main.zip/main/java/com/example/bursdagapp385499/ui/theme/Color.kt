package com.example.bursdagapp385499.ui.theme

import androidx.compose.ui.graphics.Color

val LightBlue = Color(0xFF8BD3DD)
val LightYellow = Color(0xFFFEF6E4)
val DarkBlue = Color(0xFF001858)

val DarkGrey = Color(0xFF172C66)
val Peach = Color(0xFFF3D2C1)
val Pink = Color(0xFFF582AE)